// checks for if statement ,OR operator and while loop
class test5 {
    public static void main(String[] args) {
        System.out.println((new C()).what());
    }
}

class C {
    public int what() {
        int i;
        final int x = 10;
        i=0;
        if(false | (5<x))
        while(i<(5+1))
        {
            System.out.println(i);
            i=i+1;
        }
        else 
        System.out.println(i);
        return 1+(2+3);
        
    }
}