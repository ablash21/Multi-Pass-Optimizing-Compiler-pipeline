// for loop check 
class test3
{
    public static void main(String[] args)
    {
        System.out.println((new A()).m1());
    }

}

class A
{
    
    int i ;
    public int m1()
    {
        final int a =10;
        for(i=0;i<10;i=i+1)
        System.out.println(i);
        return 2;
        
    }

}
class B extends A
{
    int c;

    public int m2()
    {
        return 3 ;
    }
    public int m3()
    {
        return this.m2();
    }
}