//checks if statement ,AND operator and method args ,array creation and access works fine
class test4
{
    public static void main(String[] args)
    {
        System.out.println((new A()).m1(1+(5+3)));
    }

}
class A
{
    int a ;
   
    int [] arr;
    public int m1(int e )
    {
        
        arr = new int[e];
        if((5<e) & (e<10))
        System.out.println(arr[(1+(1+0))]);
        else 
        System.out.println(arr[0]);
        return (new B()).m2(e+3);
    }


}
class B extends A
{
    int c;
    public int m2(int d)
    {
        return 3;
    }
}