// checks for method calls and object creation
class test2
{
    public static void main(String[] args)
    {
        System.out.println(((new B()).m2()).m3());
    }

}
class A
{
    int a ;
    int b;
    
    public  int m1()
    {
        int c;
        final int a =10;
        if(a<5)
        {
            c=2;
        }
        else
        {
            b=2;
            if(b<0)
            {
                c=3;
            }
            else
            {
                c=4;
            }
        }
        System.out.println(c);
        return 2;

    }
    public int m3()
    {
        return 3;
    }

}
class B extends A
{
    A a; 
    public A m2()
    {
        a= new A ();
        return a;
    }
}