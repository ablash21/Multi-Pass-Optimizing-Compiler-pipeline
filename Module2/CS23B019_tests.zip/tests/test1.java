// checks for arithmetic expressions with mutiple operators and parentheses
class test1
{
    public static void main(String[] args)
    {
    System.out.println((new A()).m1());
    }

}
class A
{
    int a ;
    int [] arr;
    public int m1()
    {
        a=(2+3)+(5+5);
        System.out.println(6);
        System.out.println((((2+3)+5)+5)+a);
        return 2;
    }

}
class B extends A
{
    int c;
    public int m2()
    {
        return 3;
    }
}